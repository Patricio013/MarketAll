/**
 * 
 */
/**
 * @author pato_
 *
 */
module Market {
	requires java.desktop;
}